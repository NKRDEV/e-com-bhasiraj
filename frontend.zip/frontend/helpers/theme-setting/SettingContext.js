import { createContext } from 'react';

const SettingContext = createContext();

export default SettingContext;